### Baselines compare (normAUPRC means, 6×2 matched)

| score | on mean | off mean | on−off | n |
|---|---:|---:|---:|---:|
| z_eff | nan | nan | +nan | 0 |
| eos_margin | nan | nan | +nan | 0 |
| ps_grad | nan | nan | +nan | 0 |
| r_only | nan | nan | +nan | 0 |
| lam_max | nan | nan | +nan | 0 |
| grad_norm | nan | nan | +nan | 0 |
| r_full | nan | nan | +nan | 0 |
| sam1_full | nan | nan | +nan | 0 |

---

### Per-seed values (normAUPRC)

