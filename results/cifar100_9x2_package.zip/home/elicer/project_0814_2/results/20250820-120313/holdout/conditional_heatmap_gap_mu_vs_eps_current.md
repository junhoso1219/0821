### Conditional normAUPRC heatmap

- X: gap_mu, Y: eps_current

![heatmap](/home/elicer/project_0814_2/results/20250820-120313/holdout/conditional_heatmap_gap_mu_vs_eps_current.png)
