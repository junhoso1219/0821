### 캘리브레이션 요약 (CIFAR-100, k=1, hold-out)

| variant | n | ECE_rank mean | ECE_rank median | AUPRG mean | AUPRG median |
|---|---:|---:|---:|---:|---:|
| on | 5 | 0.2793 | 0.2739 | 13.7427 | 11.672 |
| off | 6 | 0.2883 | 0.2884 | 8.7788 | 8.2141 |
