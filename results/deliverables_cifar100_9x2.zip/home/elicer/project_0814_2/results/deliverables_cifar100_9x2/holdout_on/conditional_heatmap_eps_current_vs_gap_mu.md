### Conditional normAUPRC heatmap

- X: eps_current, Y: gap_mu

![heatmap](/home/elicer/project_0814_2/results/20250820-120313/holdout/conditional_heatmap_eps_current_vs_gap_mu.png)
