### 시각 요약: Top-3 on/off (hold-out)

원본 CSV: /home/elicer/project_0814_2/results/holdout_summary_cifar100_k1.csv

#### on (정규화 AUPRC 상위)

- seed=2002 | normAUPRC=0.1547 | run=results/20250819-153348

![](results/20250819-153348/holdout/pr_curve.png)

![](results/20250819-153348/holdout/prg_curve.png)

- seed=3003 | normAUPRC=0.1525 | run=results/20250820-094904

![](results/20250820-094904/holdout/pr_curve.png)

![](results/20250820-094904/holdout/prg_curve.png)

- seed=7007 | normAUPRC=0.1513 | run=results/20250820-111909

![](results/20250820-111909/holdout/pr_curve.png)

![](results/20250820-111909/holdout/prg_curve.png)


#### off (정규화 AUPRC 상위)

- seed=3003 | normAUPRC=0.1841 | run=results/20250819-170444

![](results/20250819-170444/holdout/pr_curve.png)

![](results/20250819-170444/holdout/prg_curve.png)

- seed=5005 | normAUPRC=0.1110 | run=results/20250820-135610

![](results/20250820-135610/holdout/pr_curve.png)

![](results/20250820-135610/holdout/prg_curve.png)

- seed=9009 | normAUPRC=0.1010 | run=results/20250820-152500

![](results/20250820-152500/holdout/pr_curve.png)

![](results/20250820-152500/holdout/prg_curve.png)


